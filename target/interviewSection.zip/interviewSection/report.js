$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/main/resources/features/interviewSection.feature");
formatter.feature({
  "name": "Interview Section",
  "description": "",
  "keyword": "Feature"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.step({
  "name": "I navigate to Interview Prep",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginSteps.iNavigateToInterviewPrep()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I should see the login page",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iShouldSeeTheLoginPage()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter \"test@yahoo.com\" in the Email input box",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginSteps.iEnterInTheEmailInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I enter \"testuser123\" in the Password input box",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iEnterInThePasswordInputBox(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click \"Login\" button",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iClickButton(String)"
});
formatter.result({
  "status": "passed"
});
formatter.scenario({
  "name": "Validate adding a new Do statement will display in Do section",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "I enter \"Talk clear\" in \"Do\" input field",
  "keyword": "When "
});
formatter.match({
  "location": "InterviewSectionSteps.iEnterInInputField(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click \"Enter Do\" button",
  "keyword": "And "
});
formatter.match({
  "location": "LoginSteps.iClickButton(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I validate \"Talk clear\" is displayed in \"Do\" section",
  "keyword": "Then "
});
formatter.match({
  "location": "InterviewSectionSteps.iValidateIsDisplayedInSection(String,String)"
});
formatter.result({
  "status": "passed"
});
});